<?php
include 'db.php';
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
  $result = $conn->query("SELECT * FROM todos ORDER BY id DESC");
  $todos = [];
  while ($row = $result->fetch_assoc()) {
    $todos[] = $row;
  }
  echo json_encode($todos);
}

if ($method === 'POST') {
  $data = json_decode(file_get_contents("php://input"), true);
  $content = $conn->real_escape_string($data['content']);
  $result = $conn->query("INSERT INTO todos (content, completed) VALUES ('$content', 0)");
  echo json_encode(['success' => $result]);
}

if ($method === 'DELETE') {
  $id = $_GET['id'];
  $result = $conn->query("DELETE FROM todos WHERE id=$id");
  echo json_encode(['success' => $result]);
}

if ($method === 'PUT') {
  $id = $_GET['id'];
  $data = json_decode(file_get_contents("php://input"), true);
  $content = isset($data['content']) ? $conn->real_escape_string($data['content']) : null;
  $completed = isset($data['completed']) ? (int)$data['completed'] : null;

  if ($content !== null) {
    $result = $conn->query("UPDATE todos SET content='$content' WHERE id=$id");
  } else if ($completed !== null) {
    $result = $conn->query("UPDATE todos SET completed=$completed WHERE id=$id");
  }

  echo json_encode(['success' => $result]);
}
?>
