<?php
include 'db.php';
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
  $result = $conn->query("SELECT * FROM notes ORDER BY id DESC");
  $notes = [];
  while ($row = $result->fetch_assoc()) {
    $notes[] = $row;
  }
  echo json_encode($notes);
}

if ($method === 'POST') {
  $data = json_decode(file_get_contents("php://input"), true);
  $content = $conn->real_escape_string($data['content']);
  $result = $conn->query("INSERT INTO notes (content) VALUES ('$content')");
  echo json_encode(['success' => $result]);
}

if ($method === 'DELETE') {
  $id = $_GET['id'];
  $result = $conn->query("DELETE FROM notes WHERE id=$id");
  echo json_encode(['success' => $result]);
}

if ($method === 'PUT') {
  $id = $_GET['id'];
  $data = json_decode(file_get_contents("php://input"), true);
  $content = $conn->real_escape_string($data['content']);
  $result = $conn->query("UPDATE notes SET content='$content' WHERE id=$id");
  echo json_encode(['success' => $result]);
}
?>
