// Load Notes
function loadNotes() {
  fetch("api/notes.php")
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("notesContainer");
      container.innerHTML = "";
      data.forEach(note => {
        const div = document.createElement("div");
        div.className = "note";
        div.innerHTML = `
          <div><strong>${note.content}</strong></div>
          <div class="note-buttons">
            <button onclick="editNote(${note.id})">Edit</button>
            <button onclick="deleteNote(${note.id})">Delete</button>
          </div>
        `;
        container.appendChild(div);
      });
    });
}

// Load Todos
function loadTodos() {
  fetch("api/todos.php")
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("todosContainer");
      container.innerHTML = "";
      data.forEach(todo => {
        const div = document.createElement("div");
        div.className = "todo";
        div.innerHTML = `
          <div class="${todo.completed == 1 ? 'completed' : ''}">
            ${todo.content}
          </div>
          <div class="todo-buttons">
            <button onclick="toggleCompletion(${todo.id}, ${todo.completed == 1 ? 0 : 1})">${todo.completed == 1 ? "Undo" : "Complete"}</button>
            <button onclick="editTodo(${todo.id})">Edit</button>
            <button onclick="deleteTodo(${todo.id})">Delete</button>
          </div>
        `;
        container.appendChild(div);
      });
    });
}

// Add Note
function addNote() {
  const content = document.getElementById("noteInput").value.trim();
  if (content === "") return alert("Please write a note.");

  fetch("api/notes.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content })
  })
    .then(res => res.json())
    .then(() => {
      loadNotes();
      document.getElementById("noteInput").value = "";
    });
}

// Add Todo
function addTodo() {
  const content = document.getElementById("todoInput").value.trim();
  if (content === "") return alert("Please write a to-do.");

  fetch("api/todos.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content })
  })
    .then(res => res.json())
    .then(() => {
      loadTodos();
      document.getElementById("todoInput").value = "";
    });
}

// Delete Note
function deleteNote(id) {
  fetch("api/notes.php?id=" + id, { method: "DELETE" })
    .then(res => res.json())
    .then(() => loadNotes());
}

// Delete Todo
function deleteTodo(id) {
  fetch("api/todos.php?id=" + id, { method: "DELETE" })
    .then(res => res.json())
    .then(() => loadTodos());
}

// Edit Note
function editNote(id) {
  const newContent = prompt("Edit your note:");
  if (!newContent) return;

  fetch("api/notes.php", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, content: newContent })
  })
    .then(res => res.json())
    .then(() => loadNotes());
}

// Edit Todo
function editTodo(id) {
  const newContent = prompt("Edit your to-do:");
  if (!newContent) return;

  fetch("api/todos.php", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, content: newContent })
  })
    .then(res => res.json())
    .then(() => loadTodos());
}

// Toggle Complete
function toggleCompletion(id, completed) {
  fetch("api/todos.php", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, completed })
  })
    .then(res => res.json())
    .then(() => loadTodos());
}

// Dark Mode
document.getElementById("darkModeToggle").onclick = () => {
  document.body.classList.toggle("dark-mode");
};

// Load on start
window.onload = function () {
  loadNotes();
  loadTodos();
};
